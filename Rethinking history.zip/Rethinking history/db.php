<?php
    $host='localhost';
    $username='root';
    $password='';
    $dbname = "loginpage";
    $connect=mysqli_connect($host,$username,$password,"$dbname");
    if(!$connect)
        {
            echo "<script>alert('failed to insert')</script>";
        }
?>