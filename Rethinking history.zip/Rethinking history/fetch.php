<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Users table</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<style type="text/css">
.bs-example{
margin: 20px;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
$('[data-toggle="tooltip"]').tooltip();   
});
</script>
</head>
<body>
<div class="bs-example">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="page-header clearfix">
<h2 class="pull-left">Users List</h2>
</div>
<?php
include_once 'db.php';
$result = mysqli_query($connect,"SELECT * FROM profile_edit");
?>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<table class='table table-bordered table-striped'>
<tr>
<td>First Name</td>
<td>Last Name</td>
<td>Email Address</td>
<td>Phone</td>
<td>Qualification1</td>
<td>Qualification2</td>
<td>Qualification3</td>
<td>Qualification4</td>
<td>Gender</td>
<td>DOB</td>
<td>Places Lived 1</td>
<td>Places Lived 2</td>
<td>Ideological Inclination 1</td>
<td>Ideological Inclination 2</td>
<td>About Me/Certain Experience</td>
</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["fname"]; ?></td>
<td><?php echo $row["lname"]; ?></td>
<td><?php echo $row["email"]; ?></td>
<td><?php echo $row["phone"]; ?></td>
<td><?php echo $row["qualification1"]; ?></td>
<td><?php echo $row["qualification2"]; ?></td>
<td><?php echo $row["qualification3"]; ?></td>
<td><?php echo $row["qualification4"]; ?></td>
<td><?php echo $row["contact"]; ?></td>
<td><?php echo $row["dob"]; ?></td>
<td><?php echo $row["address11"]; ?></td>
<td><?php echo $row["address12"]; ?></td>
<td><?php echo $row["ideas11"]; ?></td>
<td><?php echo $row["ideas12"]; ?></td>
<td><?php echo $row["me"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
<?php
}
else{
echo "No result found";
}
?>
</div>
</div>        
</div>
</div>
</body>
</html>