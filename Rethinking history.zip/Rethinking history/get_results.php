<?php
error_reporting(0);
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "loginpage";

    $connect = mysqli_connect($servername, $username, $password, $database);
	
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
    }
	
    // Retrieve the search results here

$result= $_POST['search'];
$result= strtolower($result);
 if ($result=="microsoft bing")
header ('Location:http://www.bing.com/ ');

if ($result=="yahoo")
header ('Location: http://www.yahoo.com/');

if ($result=="google")
header ('Location:http://www.google.com/ ');

if ($result=="torrentz")
header ('Location:http://www.torrentz.com/ ');

if ($result=="baidu")
header ('Location: http://www.baidu.com/');

if ($result=="yandex")
header ('Location:http://www.yandex.ru/ ');
if ($result=="wikia search")
header ('Location: http://search.wikia.com/wiki/Search_Wikia');
if ($result=="webcrawler")
header ('Location:http://www.webcrawler.com/');
if ($result=="rediff")
header ('Location: http://www.rediff.com/');



    $param = "%{$_GET['search']}%";
    $query = mysqli_prepare($connect, "SELECT * FROM articlesearchresult WHERE Description LIKE ?");
    mysqli_stmt_bind_param($query, "s", $param);
    mysqli_stmt_execute($query);
    $results = mysqli_stmt_get_result($query);
    $rows = mysqli_num_rows($results);
    mysqli_stmt_close($query);

    if ($rows > 0) {
        echo "<h2>Search results for: {$_GET['search']}</h2>";
             
        while ($result = mysqli_fetch_array($results)) {
            $result_title=$result['Title'];
            $result_url=$result['URL'];
            $result_preview=$result['Preview'];
				
            echo "<div class='search_result'> 						
                <h3><a href='$result_link'>$result_title</a></h3>
                <article><a href='$result_url'>$result_preview</a></article>			
            </div>";
        }   
    } else {
        echo "<h2>No results found for your search: {$_GET['search']}</h2>";
    }


?>