<!DOCTYPE html>
<html lang="en">
<head>
    <title>Article Results Anonymous</title>
</head>

<link rel="stylesheet" type="text/css" href="Recommended.css">
<script src="https://kit.fontawesome.com/a7bf94e240.js" crossorigin="anonymous"></script>
<script src="recomend.js"></script>

<body>
<form  method="POST">
    <div class="navigation">
			<h1 id="title">RETHINKING HISTORY</h1> 
            <!-- <li class="main_nav_button"><i class="fa-solid fa-bars"></i></li> -->
			<li><i class= "<?php echo(basename($_SERVER['PHP_SELF'])=="notification.php")?"active":"";?>"href="#"></i><i class="fa-solid fa-bell"></i></li>
			<li><i href="signup.php" class="fa-solid fa-circle-user"></i></li>
			<li><i class="<?php echo(basename($_SERVER['PHP_SELF'])=="Recommended.php")?"active":"";?>"href="#">Articles</i></li>
			<li><i class="<?php echo(basename($_SERVER['PHP_SELF'])=="community.php")?"active":"";?>"href="#">Community</i></li>
			<li><i class="<?php echo(basename($_SERVER['PHP_SELF'])=="bookmark.php")?"active":"";?>"href="#">Bookmarks</i></li>
	        <li><i class="<?php echo(basename($_SERVER['PHP_SELF'])=="about.php")?"active":"";?>"href="#">About</i></li>
	</div>
    
	<div class="<?php echo(basename($_SERVER['PHP_SELF'])=="search.php")?"active":"";?>"href="#" id="search">
			<i class="search_button fa fa-search"></i>
			<input class="search_box" type="text" placeholder=" Search here!" name="search" oninput="showResetButton()">
            <i class="delete_search_text fa fa-xmark" style="display: none" onclick="searchReset()"></i>
	
    
        </form>
        <i><?php echo basename($_SERVER['PHP_SELF']);?></i>
        </div>
	<div class="headline">
		<li id="recommended" class="sub_nav">Recommended</li>
    </div>

    <div class="articles">
        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>
        
        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

        <div class="each_article">
            <div class="article_image"></div>
            <div class="article_about"></div>
        </div>

    </div>

</body>

</html>
