<?php

$connect= mysqli_connect("localhost","root","","loginpage");


//collect post variables
if(isset($_POST['submit'])){
$fname= $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$phone= $_POST['phone'];
$qualification1 = $_POST['qualification1'];
$qualification2 = $_POST['qualification2'];
$qualification3 = $_POST['qualification3'];
$qualification4= $_POST['qualification4'];
$contact = $_POST['contact'];
$dob = $_POST['dob'];
$address11 = $_POST['address11'];
$address12 = $_POST['address12'];
$ideas11 = $_POST['ideas11'];
$ideas12 = $_POST['ideas12'];
$me= $_POST['me'];
$query="INSERT INTO profile_edit(fname,lname,email,phone,qualification1,qualification2,qualification3,qualification4,contact,dob,address11,address12,ideas11,ideas12,me)VALUES('$fname', '$lname', '$email','$phone','$qualification1','$qualification2','$qualification3','$qualification4','$contact','$dob','$address11','$address12','$ideas11','$ideas12','$me')";
$result=mysqli_query($connect,$query);
 
//echo $sql;

//execute the query
if($result){

    echo "<script>alert('Successfully inserted')</script>";

    
}
else{
   
   echo "<script>alert('failed to insert')</script>";
}
 }
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Profile Edit</title>
    <script src="https://kit.fontawesome.com/a7bf94e240.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="profile_edit.css">
  </head>
  <body>
    <div class="navigation">
    <ul>
      <h1 id="title">RETHINKING HISTORY</h1>
      <li id="notif"><i class="fa-solid fa-bell"></i></li>
      <li id="login"><i class="fa-solid fa-circle-user"></i></li>
      <li id="about"><a href="">About</a></li>
      <li><a href="">Community</a></li>
      <li><a href="">Bookmarks</a></li>
      <li><a href="">Articles</a></li>
      </ul>
  </div>

  <br>


  <div class="ultimate">
    <div class="testbox">
      <form method="post">
        <div class="colums">
          <div class="item">
            <label for="fname"> First Name</label>
            <input id="fname" type="text" name="fname">
          </div>
          <div class="item">
            <label for="lname"> Last Name</label>
            <input id="lname" type="text" name="lname">
          </div>
        </div>
        <br>
        <h3 align="center">Contact Information</h3>
        <div class="colums">
          <div class="item">
            <label for="email">Email Address</label>
            <input id="email" type="email"   name="email">
          </div>
          <div class="item">
            <label for="phone">Phone</label>
            <input id="phone" type="tel"   name="phone">
          </div>
        </div>
        <br>
        <h3 align="center">Qualification Details (Fill out in the format: Degree Name | Institute | Date of Graduation)</h3>
        <div class="colums">
          <div class="item">
            <label for="qualification1">Qualification 1</label>
            <input id="qualification1" type="text"   name="qualification1">
          </div>
          <div class="item">
            <label for="qualification2">Qualification 2</label>
            <input id="qualification2" type="text"   name="qualification2">
          </div>
          <div class="item">
            <label for="qualification3">Qualification 3</label>
            <input id="qualification3" type="text"   name="qualification3">
          </div>
          <div class="item">
            <label for="qualification4">Qualification 4</label>
            <input id="qualification4" type="text" name="qualification4">
          </div>
        </div>
        <br>
        <h3 align="center">Profile Bio</h3>
        <div class="colums">
          <div class="question">
            <label>Gender</label>
            <div class="question-answer">
              <div>
                <input type="radio" value="male" id="radio_4" name="contact"/>
                <label for="radio_4" class="radio"><span>M</span></label>
              </div>
              <div>
                <input  type="radio" value="female" id="radio_5" name="contact"/>
                <label for="radio_5" class="radio"><span>F</span></label>
              </div>
              <div>
                <input  type="radio" value="LGBTQ+" id="radio_6" name="contact"/>
                <label for="radio_6" class="radio"><span>LGBTQ+</span></label>
              </div>
            </div>
          </div>
          <div class="DOB">
            <label>DOB</label>
            <input id="dob" type="date" name="dob">
          </div>
          <div class="item">
            <label for="address11">Places Lived 1</label>
            <input id="address11" type="text"   name="address11">
          </div>
          <div class="item">
            <label for="address12">Places Lived 2</label>
            <input id="address12" type="text"   name="address12">
          </div>
          <div class="item">
            <label for="ideas11">Ideological Inclination 1</label>
            <input id="ideas11" type="text"   name="ideas11">
          </div>
          <div class="item">
            <label for="ideas12">Ideological Inclination 2</label>
            <input id="ideas12" type="text" name="ideas12">
          </div>
        </div>
        <div class="item">
            <label for="me">About Me/Certain Experience</label>
            <textarea name="me" id="me" cols="100" rows="8"></textarea>
        </div>
        <br>
        <div class="btn-block">
          <button type="submit" name="submit" href=""><a href="profile_post_user.html">Submit</a></button>
        </div>
      </form>
    </div>
  </div>
  </body>
</html>