function showResetButton() {
    if (document.getElementsByClassName("search_box")[0].value == '')
        document.getElementsByClassName("delete_search_text")[0].style.display = "none";
    else
        document.getElementsByClassName("delete_search_text")[0].style.display = "inline";
}

function searchReset() {
    document.getElementsByClassName("search_box")[0].value = '';
    document.getElementsByClassName("delete_search_text")[0].style.display = "none";
}
