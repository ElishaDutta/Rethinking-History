<?php
error_reporting(0);
session_start();
include('app_logic.php');
//create a database connection
$connect= mysqli_connect("localhost","root","","loginpage");
//collect post variables
if(isset($_POST['submit'])){
$username = $_POST['username'];
$password = $_POST['password'];
$query="INSERT INTO login (username,password)VALUES('$username','$password')";
$result=mysqli_query($connect,$query);
 //execute the query
if($result){
echo "<script>alert('Successfully inserted')</script>";
}
else{
echo "<script>alert('failed to insert')</script>";
}
 }
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login Form</title>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
<link rel="stylesheet" type="text/css" href="signin.css">
</head>
<body>

	<div class="main">
		<div class="logo">
			<h2>Rethinking History</h2>
		</div>
		<div class="signin">
			<h1>Welcome!</h1>
			<p>Sign into your account</p>		
            <form class="signin-form" action="signin.php"  method="POST">
			<?php include('messages.php'); ?>
			<label>Username</label>
			<i class="far fa-user">
			<input type="email" name="username" placeholder="john@gmail.com" required></i>   
			<label>Password</label>
			<i class="fas fa-unlock-alt">
			<input type="Password" name="password" placeholder="********" required></i>
			<a href="email.php">Forget Password ?</a><br>
            <button type="submit"  class="login-btn" name="submit">SUBMIT</button>
			<h5>Need an account?</h5> <a href="signup.php">Signup</a> 
            </form>
    	<ul>
    		<li><i class="fab fa-facebook-f"></i></li>
    		<li><i class="fab fa-twitter"></i></li>
    		<li><i class="fab fa-google"></i></li>
    		<!-- <li><i class="fab fa-instagram"></i></li> -->
    	</ul>
    	</div>
	</div>
  


</body>
</html>